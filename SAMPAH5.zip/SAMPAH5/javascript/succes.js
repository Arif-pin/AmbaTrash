// Redirect ke dashboard setelah 3 detik
setTimeout(() => {
    window.location.href = "../dashboard.php";
}, 3000);